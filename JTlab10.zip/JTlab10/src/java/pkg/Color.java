
package pkg;

public class Color 
{
    String name;
    String color;
    
    public Color(String name,String color)
    {
        this.name=name;
        this.color=color;
    }
    public void setName(String name)
    {
        this.name=name;
    }
    public String getName()
    {
        return name;
    }
   public void setcolor(String color)
    {
        this.color=color;
    }
    public String getcolor()
    {
        return color;
    }
}
