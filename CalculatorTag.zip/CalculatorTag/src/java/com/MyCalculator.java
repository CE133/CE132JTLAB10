package com;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class MyCalculator extends SimpleTagSupport{
    String n1;
    String n2;
    String o;
    String r;

    @Override
    public String toString() {
        return "MyCalculator{" + "n1=" + n1 + ", n2=" + n2 + ", o=" + o + ", r=" + r + '}';
    }

    public String getN1() {
        return n1;
    }

    public void setN1(String n1) {
        this.n1 = n1;
    }

    public String getN2() {
        return n2;
    }

    public void setN2(String n2) {
        this.n2 = n2;
    }

    public String getO() {
        return o;
    }

    public void setO(String o) {
        this.o = o;
    }

    public String getR() {
        return r;
    }

    public void setR(String r) {
        this.r = r;
    }

    public MyCalculator(String n1, String n2, String o, String r) {
        this.n1 = n1;
        this.n2 = n2;
        this.o = o;
        this.r = r;
    }

    public MyCalculator() {
    }
    public void doTag() throws JspException 
    {
            JspWriter out = getJspContext().getOut();

        try 
        {
            int n3=Integer.parseInt(n1);
            int n4=Integer.parseInt(n2);
            float r1=0;
            if(o.equals("+"))
            {
                r1=n3+n4;
            }
            if(o.equals("-"))
            {
                r1=n3-n4;
            }
            if(o.equals("*"))
            {
                r1=n3*n4;
            }
            if(o.equals("/"))
            {
                r1=n3/n4;
            }
            out.println(r1);    

        } 
        catch (java.io.IOException ex) {
            throw new JspException("Error in NewTagHandler tag", ex);
        }
    }
    
    
}
